
function eventFunction(){
  
    var e = document.getElementById("eventType").value;
    var eCost = document.getElementById("eventCost").value; //event cost --user input
    var reimburs;
   
     switch (e) {
       case "200":
           reimburs = parseFloat((eCost * .80)).toFixed(2);   
           document.getElementById("estimatedReimbursement").value = reimburs;
            break;
       case "201":
        reimburs = parseFloat((eCost * .60)).toFixed(2);   
        document.getElementById("estimatedReimbursement").value = reimburs;          
           break;
       case "202":
        reimburs = parseFloat((eCost * .75)).toFixed(2);   
        document.getElementById("estimatedReimbursement").value = reimburs;
           break;
       case "203":
        reimburs = parseFloat((eCost)).toFixed(2);   
        document.getElementById("estimatedReimbursement").value = reimburs;   
           break;
       case "204":
        reimburs = parseFloat((eCost * .90)).toFixed(2);   
        document.getElementById("estimatedReimbursement").value = reimburs;
           break;
       case "205":
        reimburs = parseFloat((eCost * .30)).toFixed(2);   
        document.getElementById("estimatedReimbursement").value = reimburs;
           break;
       default:
        document.getElementById("estimatedReimbursement").value = "choose an event type";
        console.log("Error caught calculating reimbursement amount in form.js");
     }   
   }

